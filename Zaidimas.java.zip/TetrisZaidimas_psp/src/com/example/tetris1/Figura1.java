package com.example.tetris1;

import java.util.Random;

abstract class Figura1 {

    public abstract int pradzia();
    public abstract int[] sekantis();
    public abstract int atsitiktine();
    public abstract int spalva();
    public abstract int sukti();

}

class Figura101 extends Figura1 {

    protected int[][] langiukai;
    protected int rodykle;


    public int pradzia() {
        rodykle = 0;
        return langiukai.length - 1;
    }

    public int[] sekantis() {
        int[] l=langiukai[rodykle];
        rodykle++;
        return l;
    }

    public int atsitiktine() {
        Random r = new Random();
        int kuri = Math.abs(r.nextInt()) % Figuros.figurulentele1.length;
        langiukai = Figuros.figurulentele1[kuri].clone();
        int min = 9;
        for (int i = 0; i < langiukai.length - 1; i++) {
            if (langiukai[i][1] < min)  min = langiukai[i][1];
        }
        return -min;
    }

    public int spalva() {
        int a = langiukai.length - 1;
        return langiukai[a][0];
    }

    public int sukti() {

        int[][] lan0 = langiukai.clone();
        for (int i = 0; i < langiukai.length - 1; ++i) {
            int x = langiukai[i][0];
            int y = langiukai[i][1];
            lan0[i][0] = -y;
            lan0[i][1] = x;
        }
        langiukai = lan0;
        return 0;
    }

}

class Figura102 extends Figura101 {

    public int atsitiktine() {
        Random r = new Random();
        int kuri = Math.abs(r.nextInt()) % Figuros.figurulentele2.length;
        langiukai = Figuros.figurulentele2[kuri].clone();
        int min = 9;
        for (int i = 0; i < langiukai.length - 1; i++) {
            if (langiukai[i][1] < min)  min = langiukai[i][1];
        }
        return -min;
    }
}

class Figura103 extends Figura101 {
    private int seka;
    public int atsitiktine() {
        int kuri = seka % Figuros.figurulentele1.length;
        seka++;
        langiukai = Figuros.figurulentele1[kuri].clone();
        int min = 9;
        for (int i = 0; i < langiukai.length - 1; i++) {
            if (langiukai[i][1] < min)  min = langiukai[i][1];
        }
        return -min;
    }
}