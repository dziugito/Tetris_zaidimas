package com.example.tetris1;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

public class Tetris1 extends JFrame {
    private JLabel teilute;
    private int taskai;

    public Tetris1() {
        setSize(510, 650);
        setTitle("Tetris");
        this.setLayout(new BorderLayout());

        Zaidimas zaidimas = new Zaidimas(this);
        zaidimas.setBounds(10, 10, 280, 580);
        zaidimas.setBackground(Color.LIGHT_GRAY.brighter());
        add(zaidimas);
        JPanel vpanel = new JPanel();
        vpanel.setLayout(null);
        vpanel.setBounds(330, 10, 170, 580);
        vpanel.setBackground(Color.blue);

        JButton startas1 = new JButton("Startas, 1 variantas");
        startas1.setBounds(5, 10, 160, 30);
        startas1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zaidimas.startas(new Figura101());
            }
        });
        vpanel.add(startas1);

        JButton startas2 = new JButton("Startas, 2 variantas");
        startas2.setBounds(5, 40, 160, 30);
        startas2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zaidimas.startas(new Figura102());
            }
        });
        vpanel.add(startas2);

        JButton startas3 = new JButton("Startas, 3 variantas");
        startas3.setBounds(5, 70, 160, 30);
        startas3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zaidimas.startas(new Figura103());
            }
        });
        vpanel.add(startas3);

        JButton bpauze = new JButton("Pauzė");
        bpauze.setBounds(5, 100, 160, 30);
        bpauze.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                zaidimas.pause();
            }
        });
        vpanel.add(bpauze);


        teilute = new JLabel("Sveiki atvyke!");
        vpanel.add(teilute);
        teilute.setBounds(30, 130, 160, 60);

        add(vpanel);
        JPanel xpanel = new JPanel();
        add(xpanel);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                Object[] options = {"Taip", "Ne"};
                int confirmed = JOptionPane.showOptionDialog(null, "Norite palikti žaidimą?", "Pranešimas",
                        JOptionPane.DEFAULT_OPTION, JOptionPane.PLAIN_MESSAGE, null,
                        options, options[0]);
                if (confirmed == JOptionPane.YES_OPTION) {

                    System.exit(0);
                }
            }
        });
    }

    public JLabel getTeilute() {
        return teilute;
    }

    public int getTaskai() {
        return taskai;
    }

    public void setTaskai(int taskai) {
        this.taskai = taskai;
    }

    public static void main(String[] args) {

        Tetris1 game = new Tetris1();
        game.setLocationRelativeTo(null);
        game.setVisible(true);
    }
}
