package com.example.tetris1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class Zaidimas extends JPanel {

    final int lPlotis = 10;
    final int lAukstis = 22;
    Timer timer;
    boolean isPilnas = false;
    boolean isStarted = false;
    boolean isPaused = false;
    int taskai = 0;
    int y0 = 0;
    int x0;
    int x0p = 4;
    Figura1 pfigura;
    int[][] laukas;
    ActionListener timerListener;
    garsasPasibaigus gp = new garsasPasibaigus();
    garsasLeidziantis gl = new garsasLeidziantis();
    garsasPanaikinti pe = new garsasPanaikinti();
    garsasMetant gm = new garsasMetant();

    public Zaidimas(Tetris1 parent) {

        timerListener = new ActionListener() {
            public void actionPerformed(ActionEvent actionEvent) {
                JLabel tlabel = parent.getTeilute();
                parent.setTaskai(taskai);
                tlabel.setText("Surinkti taskai: " + parent.getTaskai());
                if ((tikrintisusikirtima(pfigura, x0, y0 + 1, 0)) && !isPilnas) {
                    isPilnas = perkelti();
                    if (isPilnas) {
                        timer.stop();
                        return;
                    }
                    naikintilinijas();
                    x0 = lPlotis / 2;
                    y0 = pfigura.atsitiktine();
                } else {
                    y0++;
                    gl.play();
                }
                repaint();
            }
        };
        setFocusable(true);

        timer = new Timer(300, timerListener);

        KeyListener listener = new KeyListener() {

            @Override
            public void keyTyped(KeyEvent e) {
            }

            @Override
            public void keyPressed(KeyEvent e) {
                if (isPilnas) return;
                int keycode = e.getKeyCode();
                switch (keycode) {
                    case KeyEvent.VK_LEFT:
                        bandomJudint(pfigura, x0 - 1, y0);
                        break;
                    case KeyEvent.VK_RIGHT:
                        bandomJudint(pfigura, x0 + 1, y0);
                        break;
                    case KeyEvent.VK_UP:
                        bandomJudint(pfigura, x0, y0, 1);
                        break;
                    case KeyEvent.VK_DOWN:
                        bandomJudint(pfigura, x0, y0+1);
                        break;
                    case KeyEvent.VK_SPACE:
                        mesti(pfigura);
                        break;
                }
            }

            @Override
            public void keyReleased(KeyEvent e) {
            }
        };
        addKeyListener(listener);
    }

    public void mesti(Figura1 pfigura) {

        while (y0 < (lAukstis + 1)) {
            if (!bandomJudint(pfigura, x0, y0 + 1)) break;
        }
        timer.stop();
        perkelti();
        gm.play();
        naikintilinijas();
        x0 = x0p;
        y0 = pfigura.atsitiktine();
        repaint();
        timer.start();
    }

    public boolean bandomJudint(Figura1 pfigura, int x1, int y1) {
        int a = pfigura.pradzia();

        for (int i = 0; i < a; ++i) {
            int k[] = pfigura.sekantis();
            int x = x1 + k[0];
            int y = y1 + k[1];
            if (x < 0 || y < 0)
                return false;
        }
        if (tikrintisusikirtima(pfigura, x1, y1, 0)) return false;
        x0 = x1;
        y0 = y1;
        repaint();
        return true;
    }

    public boolean bandomJudint(Figura1 pfigura, int x0, int y0, int r) {

        if (tikrintisusikirtima(pfigura, x0, y0, r))
            return false;
        if (r!=0) pfigura.sukti();
        repaint();
        return true;
    }

    public boolean tikrintisusikirtima(Figura1 pfigura, int x, int y, int r) {
        try {
            int a = pfigura.pradzia();
            for (int i = 0; i < a; ++i) {
                int k[] = pfigura.sekantis();
                int ly = k[1];
                int lx = k[0];
                int t;
                if (r == 1) {
                    t = ly;
                    ly = lx;
                    lx = -t;
                }
                if (((ly + y) < lAukstis + 1) && (laukas[lx + x][ly + y] > 0)) return true;
                if (k[1] + y >= lAukstis) return true;

            }
        } catch (Exception e) {
            return true;
        }
        return false;
    }


    public boolean perkelti() {
        int a = pfigura.pradzia();
        for (int i = 0; i < a; ++i) {
            int k[] = pfigura.sekantis();
            int x = k[0] + x0;
            int y = k[1] + y0;
            if ((y >= 0) && (x >= 0) && (y <= lAukstis) && (x < lPlotis)) {
                laukas[x][y] = pfigura.spalva();
            }
            if (y <= 0) {
                gp.play();
                return true;
            }
        }
        return false;
    }

    public void naikintilinijas() {
        boolean nepilna;
        for (int i = 0; i < lAukstis; ++i) {
            nepilna = false;
            for (int j = 0; j < lPlotis; ++j) {
                if (laukas[j][i] == 0) {
                    nepilna = true;
                    break;
                }
            }
            if (!nepilna) {
                taskai++;
                for (int i1 = i; i1 >= 0; --i1) {
                    for (int j1 = 0; j1 < lPlotis; ++j1) {
                        int i2 = i1 - 1;
                        if (i2 < 0) {
                            laukas[j1][i1] = 0;
                        } else {
                            laukas[j1][i1] = laukas[j1][i2];
                        }
                    }
                }
                pe.play();
            }
        }
    }

    public void startas(Figura1 f) {
        if (isPaused) {
            isPaused = false;
            timer.start();
            requestFocus();
            return;
        }
        laukas = new int[lPlotis][lAukstis];
        y0 = 0;
        x0 = x0p;
        pfigura =  f;
        pfigura.atsitiktine();
        taskai = 0;
        isStarted = true;
        isPilnas = false;
        timer.start();
        requestFocus();
    }

    public void pause() {
        if (isPaused) return;
        isStarted = false;
        isPilnas = false;
        isPaused = true;
        timer.stop();
    }

    int lanPlotis() {
        return (int) getSize().getWidth() / lPlotis;
    }

    int lanAukstis() {
        return (int) getSize().getHeight() / lAukstis;
    }

    private void piestiLangeli(Graphics g, int xd, int yd, int ispalva) {
        Color colors[] = {
                new Color(230, 230, 230),   //0
                new Color(255, 20, 20),     //1
                new Color(102, 205, 20),     //2
                new Color(102, 102, 255),    //3
                new Color(255, 200, 20),    //4
                new Color(255, 10, 200),     //5
                new Color(20, 200, 200),     //6
                new Color(205, 110, 20),      //7
                new Color(205, 200, 20)       //8
        };
        Color spalva = colors[ispalva];
        int x = xd * lanPlotis();
        int y = yd * lanAukstis();
        g.setColor(spalva);
        if (ispalva!=0) {
            g.fillRect(x + 1, y + 1, lanPlotis() - 2, lanAukstis() - 2);
            g.setColor(spalva.brighter());
            g.drawLine(x, y + lanAukstis() - 1, x, y);
            g.drawLine(x, y, x + lanPlotis() - 1, y);
            g.setColor(spalva.darker().darker().darker());
            g.drawLine(x + 1, y + lanAukstis() - 1, x + lanPlotis() - 1, y + lanAukstis() - 1);
            g.drawLine(x + lanPlotis() - 1, y + lanAukstis() - 1, x + lanPlotis() - 1, y + 1);
        }
        else
            g.fillRect(x, y , lanPlotis()-1 , lanAukstis()-1 );
    }

    private void piestifigura(Graphics g, int x, int y, Figura1 figura) {
        int a = pfigura.pradzia();
        for (int i = 0; i < a; ++i) {
            int k[] = pfigura.sekantis();
            piestiLangeli(g, x + k[0], y + k[1], figura.spalva());
        }
    }

    private void piestiLauka(Graphics g) {
        for (int i = 0; i < lPlotis; ++i) {
            for (int j = 0; j < lAukstis; ++j) {
                piestiLangeli(g, i, j, laukas[i][j]);
            }
        }
    }

    public void paint(Graphics g) {
        super.paint(g);
        if (laukas != null) {
            piestiLauka(g);
        }
        if (pfigura != null) {
            piestifigura(g, x0, y0, pfigura);
        }
    }

}

