package com.example.tetris1;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

class Garsai {
    Clip clip;
    int yrafailas;

    public void setFile(String soundFileName) {

        try {
            File file = new File(soundFileName).getAbsoluteFile();
            AudioInputStream sound = AudioSystem.getAudioInputStream(file);
            clip = AudioSystem.getClip();
            clip.open(sound);
            yrafailas=1;

        } catch (Exception e) {
            System.out.print(soundFileName +" file not found");
            yrafailas=0;

        }
    }

    public void play() {
      if (yrafailas==1) {
        clip.setFramePosition(0);
        clip.start();}
    }

}

class garsasLeidziantis extends Garsai {
    String leidziantis = "src/com/example/Garsai/step26.wav";

    public garsasLeidziantis() {
        setFile(leidziantis);
    }
}

class garsasMetant extends Garsai {
    String metant = "src/com/example/Garsai/fall.wav";

    public garsasMetant() {
        setFile(metant);
    }
}

class garsasPasibaigus extends Garsai {
    String pasibaigus = "src/com/example/Garsai/gameover.wav";

    public garsasPasibaigus() {
        setFile(pasibaigus);
    }
}

class garsasPanaikinti extends Garsai {
    String panaikinus = "src/com/example/Garsai/line.wav";

    public garsasPanaikinti() {
        setFile(panaikinus);
    }
}
